(() => {
  const menuToggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector("#primary-nav");
  const year = document.querySelector("#year");
  const dateInput = document.querySelector('input[name="date"]');
  const form = document.querySelector("#booking-form");
  const status = document.querySelector("#form-status");

  if (year) year.textContent = new Date().getFullYear();

  if (dateInput) {
    const today = new Date();
    const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000)
      .toISOString().slice(0, 10);
    dateInput.min = localDate;
  }

  if (menuToggle && nav) {
    menuToggle.addEventListener("click", () => {
      const isOpen = menuToggle.getAttribute("aria-expanded") === "true";
      menuToggle.setAttribute("aria-expanded", String(!isOpen));
      menuToggle.setAttribute("aria-label", isOpen ? "Open navigation" : "Close navigation");
      nav.classList.toggle("is-open", !isOpen);
    });
    nav.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        nav.classList.remove("is-open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Open navigation");
      });
    });
  }

  if (form) {
    form.addEventListener("submit", event => {
      event.preventDefault();
      if (!form.reportValidity()) return;

      const data = new FormData(form);
      const subject = encodeURIComponent(`Appointment request — ${data.get("name")}`);
      const body = encodeURIComponent(
`Hi Northline Barbore,

I'd like to request an appointment.

Name: ${data.get("name")}
Phone: ${data.get("phone")}
Email: ${data.get("email")}
Service: ${data.get("service")}
Preferred date: ${data.get("date")}
Additional notes: ${data.get("message") || "None"}

Please contact me to confirm availability.

Thank you.`
      );

      // Replace this placeholder address with the business's real booking email.
      const bookingEmail = "hello@example.com";
      status.textContent = "Opening your email app with the appointment request. Your appointment is not confirmed until the shop replies.";
      window.location.href = `mailto:${bookingEmail}?subject=${subject}&body=${body}`;
    });
  }
})();