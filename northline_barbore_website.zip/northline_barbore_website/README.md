# Northline Barbore — Website Project

A responsive, single-page barbershop website built with HTML, CSS, and vanilla JavaScript.

## Assumptions made
- “Northline Barbore” is treated as a barbershop / barbering business because the name appears to refer to a barber.
- USA customers are the target audience, but the exact city, state, address, opening hours, contact details, and service area were not provided.
- Service names, sample prices, and durations are illustrative and must be confirmed by the business owner.
- No real booking platform or backend was provided. The appointment form validates the user's entries and prepares an email via the user's email app. It does **not** store bookings or confirm appointments.
- The WhatsApp link and phone/email details are placeholders and must be replaced with real business details before launch.

## Files
- `index.html` — page structure, content, metadata, and basic LocalBusiness structured data.
- `styles.css` — responsive layout, colors, typography, and styling.
- `script.js` — mobile navigation, date minimum, and appointment-request email behavior.

## Run locally
1. Download and unzip the project.
2. Open `index.html` in a browser, or use a local development server (recommended).
3. Edit the placeholder contact information and service details before publishing.

## Required pre-launch edits
Search the project for these placeholders and replace them:
- `hello@example.com` — business and booking email
- `+1-555-010-2020` / `15550102020` — phone number and WhatsApp number in international format
- `[Your City]`, `[Add street address]`, `[City, State ZIP]`, `Add city`, `Add state`, `Add ZIP code`
- `https://example.com` — real canonical website URL / structured data URL
- Sample prices, services, durations, and opening hours

## Booking functionality
The form uses browser validation and opens the visitor's configured email application with a pre-filled appointment request. To accept bookings reliably without depending on the visitor's email app, connect a booking service or implement a backend/form endpoint. For automatic appointment confirmation, calendar availability, reminders, or payment, configure a real booking platform and its credentials.

## SEO / deployment checklist
- Set the real domain, canonical URL, and social sharing image.
- Verify the actual business name and NAP (name, address, phone) consistency.
- Add a sitemap and robots.txt when the production domain is known.
- Confirm the final service menu and price list.
- Test the form and WhatsApp link using real contact details.
- Test mobile, tablet, desktop, keyboard navigation, and image loading.
- Deploy to a static host such as Netlify, Vercel, or GitHub Pages, or the client's existing hosting.
- Connect the domain and enable HTTPS.
- Do not publish placeholder addresses, phone numbers, or email addresses.

## Notes
External fonts and images are loaded from Google Fonts and Unsplash, so an internet connection is needed for those assets. Replace stock imagery with licensed, client-approved images for the final site.
